package com.example.Shoyeb_2311303.SupplyChainCoordinator;

public class MonitorSupplierOrdersController
{
    @javafx.fxml.FXML
    public void initialize() {
    }}