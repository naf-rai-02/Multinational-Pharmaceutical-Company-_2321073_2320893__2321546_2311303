package com.example.Shoyeb_2311303.ClinicalTrialCoordinator;

public class loginviewcontroller
{
    @javafx.fxml.FXML
    public void initialize() {
    }}