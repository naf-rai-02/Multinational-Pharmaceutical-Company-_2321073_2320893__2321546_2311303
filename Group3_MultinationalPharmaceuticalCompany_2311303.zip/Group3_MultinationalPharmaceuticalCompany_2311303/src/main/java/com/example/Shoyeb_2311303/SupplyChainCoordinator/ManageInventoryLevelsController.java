package com.example.Shoyeb_2311303.SupplyChainCoordinator;

public class ManageInventoryLevelsController
{
    @javafx.fxml.FXML
    public void initialize() {
    }}